package com.walmart.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
@EnableTransactionManagement
public class StudentmanagementApplication{

	public static void main(String[] args) {
		SpringApplication.run(StudentmanagementApplication.class, args);
	}
	
	
	
	@Bean
	public WebMvcConfigurer getWebMvcConfigurer()
	{
		WebMvcConfigurer configurer = new WebMvcConfigurer() {
			
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedMethods("*").allowedOrigins("*");
			}
		};
		return configurer;
	}
}