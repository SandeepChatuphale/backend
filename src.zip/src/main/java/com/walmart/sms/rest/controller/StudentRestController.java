package com.walmart.sms.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.sms.model.Student;
import com.walmart.sms.repository.StudentRepository;

@RestController
@RequestMapping("/api/student")
public class StudentRestController {

	@Autowired
	private StudentRepository repo;
	
		
	@GetMapping
	public List<Student> findAllStudents()
	{
		System.out.println("==========================findAllStudents==========================");
		return this.repo.findAll();
	}
	

	
	@GetMapping("/{rollNumber}")
	public Student findStudentByRollNumber(@PathVariable int rollNumber)
	{
		System.out.println("==================findStudentByRollNumber==============================");
		return this.repo.findById(rollNumber).get();
	}
	
	@ResponseStatus(code = HttpStatus.NOT_FOUND)
	@ExceptionHandler(Exception.class)
	public void handleException(Exception e)
	{
		System.out.println(e.toString());
	}
	
	
	@ResponseStatus(code = HttpStatus.CREATED)
	@PostMapping
	public Student createNewStudent(@RequestBody Student newStudent) throws InterruptedException
	{
		System.out.println("============createNewStudent=====================");
		Student insertedStudent = this.repo.save(newStudent);
		System.out.println(insertedStudent);
		return insertedStudent;
	}
	
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	@DeleteMapping("/{rollNumber}")
	public void deleteStudentByRollNumber(@PathVariable int rollNumber)
	{
		System.out.println("============deleteStudentByRollNumber=====================");
		this.repo.deleteById(rollNumber);
	}
	
	@PutMapping("/{rollNumber}")
	public Student updateStudent(@PathVariable int rollNumber,@RequestBody Student existingStudent) throws InterruptedException
	{
		System.out.println("================updateStudent========================");
		existingStudent.setId(rollNumber);
		System.out.println(existingStudent);
		return this.repo.save(existingStudent);
	}
	
}
